//
// Created by Octavian Custura on 21/03/2020.
//
#include "TestFootage.h"
#include "Footage.h"
#include <cassert>

void TestFootage::test_all() {
    test_compareDate_IncreasingDates();
    test_dateToString_emptyDate_zeroDate();
}

void TestFootage::test_compareDate_IncreasingDates() {
    auto Date1 = Date(12, 12, 2020);
    auto Date2 = Date(13, 12, 2020);
    assert(Date1 < Date2);
}

void TestFootage::test_dateToString_emptyDate_zeroDate() {
    auto date = Date();
    assert(date.toString() == "0-0-0");
}
