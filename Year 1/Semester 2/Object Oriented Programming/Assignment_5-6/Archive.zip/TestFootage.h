//
// Created by Octavian Custura on 21/03/2020.
//

#ifndef ASSIGNMENT_5_6_TESTFOOTAGE_H
#define ASSIGNMENT_5_6_TESTFOOTAGE_H

class TestFootage {
private:
    static void test_compareDate_IncreasingDates();

    static void test_dateToString_emptyDate_zeroDate();

    static void test_FootageGetterSetter_ValidFootage();
public:
    static void test_all();
};


#endif //ASSIGNMENT_5_6_TESTFOOTAGE_H
