//
// Created by Octavian Custura on 08/05/2020.
//

#include "GUI.h"
#include <QtWidgets>
#include <qlayout.h>
#include <QFormLayout>
#include <vector>
#include <iostream>
#include <qmessagebox.h>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QLegend>
#include <QtCharts/QBarCategoryAxis>

QT_CHARTS_USE_NAMESPACE

GUI::GUI(Service &service1): service(service1){
	initGUI();
	makeConnections();
}

void GUI::initGUI() {
	// Initiate elements
	footageListWidget = new QListWidget;
	titleLineEdit = new QLineEdit;
	typeLineEdit = new QLineEdit;
	dateLineEdit = new QLineEdit;
	accessCountLineEdit = new QLineEdit;
	linkLineEdit = new QLineEdit;
	repositoryLineEdit = new QLineEdit{};
	myListLineEdit = new QLineEdit{};
	setPathRepository = new QPushButton{"Set repository"};
	setPathMyList = new QPushButton{"Set My List"};

	buttonAdd = new QPushButton{"Add"};
	buttonRemove = new QPushButton{"Remove"};
	buttonUpdate = new QPushButton{"Update"};

	tabWidget = new QTabWidget;
	auto *parentLayout = new QVBoxLayout(this);
	parentLayout->addWidget(tabWidget);

	QWidget* mainWidget = new QWidget();
	QWidget* modeAWidget = new QWidget();
	// Initiate main layout
	QVBoxLayout* mainLayout = new QVBoxLayout(modeAWidget);

	//Set path
	QVBoxLayout* setPathLayout = new QVBoxLayout{};

	QHBoxLayout* setRepositoryLayout = new QHBoxLayout{};
	QLabel* repoLabel = new QLabel("Repository");
	repoLabel->setFixedWidth(75);
	setRepositoryLayout->addWidget(repoLabel);
	setPathRepository->setFixedWidth(150);
	setRepositoryLayout->addWidget(repositoryLineEdit);
	setRepositoryLayout->addWidget(setPathRepository);
	setPathLayout->addLayout(setRepositoryLayout);

	QHBoxLayout* setMyListLayout = new QHBoxLayout{};
	QLabel* myListLabel = new QLabel("My list");
	myListLabel->setFixedWidth(75);
	setMyListLayout->addWidget(myListLabel);
	setPathMyList->setFixedWidth(150);
	setMyListLayout->addWidget(myListLineEdit);
	setMyListLayout->addWidget(setPathMyList);
	setPathLayout->addLayout(setMyListLayout);

	mainLayout->addLayout(setPathLayout);

	QHBoxLayout * adminMode = new QHBoxLayout();
	// Initiate functionality
	QVBoxLayout * functionality = new QVBoxLayout();
	// Text edits for Footage
	QFormLayout * footageDetails = new QFormLayout{};
	footageDetails->addRow("Title", titleLineEdit);
	footageDetails->addRow("Type", typeLineEdit);
	footageDetails->addRow("Date", dateLineEdit);
	footageDetails->addRow("Access Count", accessCountLineEdit);
	footageDetails->addRow("Link", linkLineEdit);
	functionality->addLayout(footageDetails);

	// Buttons
	QGridLayout* buttonsLayout = new QGridLayout{};
	buttonsLayout->addWidget(buttonAdd, 0, 0);
	buttonsLayout->addWidget(buttonRemove, 0, 1);
	buttonsLayout->addWidget(buttonUpdate, 0, 2);
	functionality->addLayout(buttonsLayout);

	adminMode->addLayout(functionality);
	adminMode->addWidget(footageListWidget);

	mainLayout->addLayout(adminMode);
	modeAWidget->setLayout(mainLayout);
	tabWidget->addTab(modeAWidget, "Mode A");
	QVBoxLayout* statisticLayout = new QVBoxLayout();
	QWidget* statisticsWidget = new QWidget();

	dataRepresentation = new QChart();
	dataRepresentation->setTitle("Views");
	dataRepresentation->setAnimationOptions(QChart::SeriesAnimations);
	QChartView* chartView = new QChartView(dataRepresentation);
	statisticLayout->addWidget(chartView);
	statisticsWidget->setLayout(statisticLayout);
	tabWidget->addTab(statisticsWidget, "Statistics");

}

void GUI::populateList() {
	footageListWidget->clear();

	std::vector<Footage> listOfFootage = service.getAllElements();
	for (const auto& footage: listOfFootage) {
		footageListWidget->addItem(QString::fromStdString(footage.toString()));
	}
}

void GUI::makeConnections() {
	QObject::connect(footageListWidget, &QListWidget::itemSelectionChanged, [this]() {
		int selectedIndex = this->getSelectedFootage();

		if (selectedIndex < 0){
			titleLineEdit->clear();
			typeLineEdit->clear();
			dateLineEdit->clear();
			accessCountLineEdit->clear();
			linkLineEdit->clear();
			return;
		}
		Footage footage = service.getAllElements().at(selectedIndex);
		this->titleLineEdit->setText(QString::fromStdString(footage.getTitle()));
		this->typeLineEdit->setText(QString::fromStdString(footage.getType()));
		this->dateLineEdit->setText(QString::fromStdString(footage.getDate().toString()));
		this->accessCountLineEdit->setText(QString::fromStdString(std::to_string(footage.getAccessCount())));
		this->linkLineEdit->setText(QString::fromStdString(footage.getLink()));
	});
	QObject::connect(setPathRepository, &QPushButton::clicked, this, &GUI::setRepository);
	QObject::connect(setPathMyList, &QPushButton::clicked, this, &GUI::setMyList);
	QObject::connect(buttonAdd, &QPushButton::clicked, this, &GUI::addFootage);
	QObject::connect(buttonRemove, &QPushButton::clicked, this, &GUI::removeFootage);
	QObject::connect(buttonUpdate, &QPushButton::clicked, this, &GUI::updateFootage);

}

int GUI::getSelectedFootage() const {
	QModelIndexList selectedIndexes = footageListWidget->selectionModel()->selectedIndexes();
	if (selectedIndexes.empty()) {
		return -1;
	}
	int selectedIndex = selectedIndexes.at(0).row();
	return selectedIndex;
}

void GUI::setRepository() {
	std::string path = repositoryLineEdit->text().toStdString();
	service.setPath(path, "repository");
	populateList();
	createStatistics();
}

void GUI::setMyList() {
	std::string path = myListLineEdit->text().toStdString();
	service.setPath(path, "mylist");
}

void GUI::addFootage() {
	std::string newTitle = titleLineEdit->text().toStdString();
	std::string newType = " " + typeLineEdit->text().toStdString();
	std::string newDateString = " " + dateLineEdit->text().toStdString();
	std::string newAccessCountString = " " + accessCountLineEdit->text().toStdString();
	std::string newLink = " " + linkLineEdit->text().toStdString();
	try {
		service.addFootage(newTitle, newType, newDateString, newAccessCountString, newLink);
	}catch(ValidationException& e) {
		QMessageBox::critical(this, "Error", e.what());
		return;
	}catch(RepositoryException& e) {
		QMessageBox::critical(this, "Error", e.what());
		return;
	}
	populateList();
	createStatistics();
	int lastElement = static_cast<int>(service.getAllElements().size() - 1);
	footageListWidget->setCurrentRow(lastElement);
}

void GUI::removeFootage() {
	std::string titleToBeRemoved = titleLineEdit->text().toStdString();
	try {
		service.deleteFootage(titleToBeRemoved);
	}catch(ValidationException& e) {
		QMessageBox::critical(this, "Error", e.what());
		return;
	}catch(RepositoryException& e) {
		QMessageBox::critical(this, "Error", e.what());
		return;
	}
	populateList();
	createStatistics();

}

void GUI::updateFootage() {
	std::string newTitle = titleLineEdit->text().toStdString();
	std::string newType = " " + typeLineEdit->text().toStdString();
	std::string newDateString = " " + dateLineEdit->text().toStdString();
	std::string newAccessCountString = " " + accessCountLineEdit->text().toStdString();
	std::string newLink = " " + linkLineEdit->text().toStdString();
	try {
		service.updateFootage(newTitle, newType, newDateString, newAccessCountString, newLink);
	} catch (ValidationException& e) {
		QMessageBox::critical(this, "Error", e.what());
		return;
	}
	populateList();
	createStatistics();

	auto footageList = service.getAllElements();
	int index = 0;
	for (const auto& footage: footageList) {
		if (footage.getTitle() == newTitle) {
			break;
		}
		index++;
	}
	footageListWidget->setCurrentRow(index);

}

void GUI::createStatistics() {
	std::vector<QBarSet*> chartSets;
	chartSets.clear();
	std::vector<Footage> footageList = service.getAllElements();
	for (auto footage: footageList) {
		QBarSet* set = new QBarSet(QString::fromStdString(footage.getTitle()));
		*set << footage.getAccessCount();
		chartSets.push_back(set);
	}
	dataRepresentation->removeAllSeries();
	QBarSeries* series = new QBarSeries();
	for (auto set: chartSets) {
		series->append(set);
	}
	QStringList category;
	category << "Footage title";
	QBarCategoryAxis* axis = new QBarCategoryAxis();
	axis->append(category);
	dataRepresentation->addSeries(series);
	dataRepresentation->createDefaultAxes();
	dataRepresentation->setAxisX(axis, series);
	dataRepresentation->legend()->setVisible(true);
	dataRepresentation->legend()->setAlignment(Qt::AlignBottom);

}

