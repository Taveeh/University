//
// Created by Octavian Custura on 16/03/2020.
//

#pragma once

#include "domain.h"
#define FIRST_CAPACITY 5

typedef Map* TypeOfElement;

typedef struct {
    TypeOfElement* dynamicArrayElements;
    int numberOfElements;
    int capacityOfDynamicArray;
} DynamicArray;

/*
 * Function to delete an element from a given position in dynamic array
 * Input:
 * DynamicArray* - dynamic array
 * int - position
 * Output:
 * 1 - if element was deleted
 * 0 - otherwise
 */
int deleteElementFromPosition(DynamicArray *dynamicArray, int position);

/*
 * Constructor
 */
DynamicArray* createDynamicArray(int capacity);

/*
 * Destructor
 */
void destroyDynamicArray(DynamicArray* dynamicArray);

/*
 * Resize dynamic array
 * Input:
 * DynamicArray* - dynamic array
 * int - new capacity of array
 * Output:
 * 1 - if resize was done
 * 0 - otherwise
 */
int resizeDynamicArray(DynamicArray* dynamicArray, int newCapacity);

/*
 * 
 */
int addElementToDynamicArray(DynamicArray* dynamicArray, TypeOfElement elementToBeAdded);

int getLengthOfDynamicArray(DynamicArray* dynamicArray);

TypeOfElement getElementOnPosition(DynamicArray* dynamicArray, int position);

int insertElementToPosition(DynamicArray* dynamicArray, int position, TypeOfElement elementToBeAdded);