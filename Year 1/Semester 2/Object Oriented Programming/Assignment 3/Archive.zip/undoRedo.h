//
// Created by Octavian Custura on 17/03/2020.
//

#pragma once

#include "dynamicArray.h"
#define INITIAL_CAPACITY 10
typedef struct {
    Map* map;
    char* typeOfOperation;
}Operation;

typedef struct {
    int undoSize;
    int undoCapacity;
    Operation** undoList;
    int flag;
    int redoSize;
    int redoCapacity;
    Operation** redoList;
}UndoRedo;

Operation* createOperation(Map* map, char* typeOfOperation);

char* getOperationType(Operation* operation);

Map* getMapFromOperation(Operation* operation);

void destroyOperation(Operation* operation);

UndoRedo* createUndoRedo();

void destroyUndoRedo(UndoRedo* undoRedo);

void addUndo(UndoRedo* undoRedo, Map* mapToBeAdded);

void addRedo(UndoRedo* undoRedo, Map *mapToBeAdded);

void resizeUndo(UndoRedo* undoRedo);

void resizeRedo(UndoRedo* undoRedo);

void clearRedo(UndoRedo* undoRedo);

void updateRedo(UndoRedo* undoRedo, Map* mapToBeEdited);

void updateUndo(UndoRedo* undoRedo, Map* mapToBeEdited);

void deleteUndo(UndoRedo* undoRedo, Map* mapToBeRemoved);

void deleteRedo(UndoRedo* undoRedo, Map* mapToBeRemoved);

Operation* getLastUndo(UndoRedo* undoRedo);

Operation* getLastRedo(UndoRedo* undoRedo);

void changeFlag(UndoRedo* undoRedo, int value);

int getFlag(UndoRedo* undoRedo);