//
// Created by Octavian Custura on 04/03/2020.
//
#pragma once

#include "repository.h"
#include "undoRedo.h"

typedef struct {
    Repository* repository;
} Service;

Service* createService(Repository* repository);

void destroyService(Service* service);

int addMapService(Service *service, int mapCatalogueNumber, char stateOfDeterioration[50], char mapType[50], int yearsOfStorage);

int removeMapService(Service *service, char mapCatalogueNumberString[]);

int updateMapService(Service *service, int mapCatalogueNumber, char stateOfDeterioration[50], char mapType[50], int yearsOfStorage);

void listAllMaps(Service *service, DynamicArray* listOfAllMapsString);

void listAllMapsByType(Service* service, char* mapType, DynamicArray* listOfAllMapsByPropertyString,  int (*property)(Map*, char*));

void sortMapsLowerThanAge(Service* service, int ageLimit, DynamicArray* sortedListOfMaps, int (*reverse)(Map*, Map*));

void undoLastOperation(Service* service);

void redoLastOperation(Service* service);