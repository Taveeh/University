//
// Created by Octavian Custura on 04/03/2020.
//

#pragma once

#include "domain.h"
#include "dynamicArray.h"
#include "undoRedo.h"

typedef struct {
    DynamicArray* listOfMaps;
    UndoRedo* undoRedo;
} Repository;

Repository* createRepository();

int addMapToRepository(Repository* repository, Map* map);

int updateMapFromRepository(Repository* repository, Map* map);

int deleteMapFromRepository(Repository* repository, int mapCatalogueNumber);

int searchMapInRepositoryByID(Repository* repository, int mapCatalogueNumber);

void destroyRepository(Repository* repository);

int getRepositoryLength(Repository* repository);

void undoRepository(Repository* repository);

void redoRepository(Repository* repository);