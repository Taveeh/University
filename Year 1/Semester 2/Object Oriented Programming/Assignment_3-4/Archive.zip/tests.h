//
// Created by Octavian Custura on 16/03/2020.
//


#ifndef ASSIGNMENT_3_TESTS_H
#define ASSIGNMENT_3_TESTS_H
#include "testDomain.h"
#include "testDynamicArray.h"
#include "testRepository.h"
#include "testService.h"

void callTestFunctions();
#endif //ASSIGNMENT_3_TESTS_H
