//
// Created by Octavian Custura on 16/03/2020.
//

#include "tests.h"
void callTestFunctions() {
    testAllDomain();
    testAllDynamicArray();
    testAllRepository();
    testAllService();
}
