#include <iostream>
#include "UI.h"
int main() {
	UI ui = UI();
	ui.runProgram();
	return 0;
}
